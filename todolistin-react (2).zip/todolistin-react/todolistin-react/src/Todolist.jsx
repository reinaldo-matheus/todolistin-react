import React, { useState, useEffect } from "react";
import './TodoList.css';

const TodoItem = ({ item, index, deletarItem, toggleComplete }) => (
    <div className={`item ${item.isCompleted ? 'completed' : ''}`}>
        <span onClick={() => toggleComplete(index)}>{item.text}</span>
        <button className="del" onClick={() => deletarItem(index)}>Deletar</button>
    </div>
);

function TodoList() {
    const [lista, setLista] = useState([]);
    const [novoItem, setNovoItem] = useState("");

    useEffect(() => {
        const storedList = JSON.parse(localStorage.getItem('lista'));
        if (storedList) setLista(storedList);
    }, []);

    useEffect(() => {
        localStorage.setItem('lista', JSON.stringify(lista));
    }, [lista]);

    function adicionarItem(form) {
        form.preventDefault();
        if (!novoItem) return;
        setLista([...lista, { text: novoItem, isCompleted: false }]);
        setNovoItem("");
    }

    function deletarItem(index) {
        const novaLista = lista.filter((_, i) => i !== index);
        setLista(novaLista);
    }

    function deletarTodos() {
        setLista([]);
    }

    function toggleComplete(index) {
        const novaLista = lista.map((item, i) => 
            i === index ? { ...item, isCompleted: !item.isCompleted } : item
        );
        setLista(novaLista);
    }

    return (
        <div>
            <h1>Lista de Tarefas</h1>
            <form onSubmit={adicionarItem}>
                <input
                    id="input-entrada"
                    type="text"
                    name="tarefa"
                    value={novoItem}
                    onChange={(e) => setNovoItem(e.target.value)}
                    placeholder="Digite sua tarefa"
                />
                <button type="submit">Adicionar</button>
            </form>
            <div className="ListaTarefas">
                {lista.length < 1 ? (
                    <p>Lista vazia</p>
                ) : (
                    lista.map((item, index) => (
                        <TodoItem 
                            key={index} 
                            item={item} 
                            index={index} 
                            deletarItem={deletarItem} 
                            toggleComplete={toggleComplete} 
                        />
                    ))
                )}
                {lista.length > 0 && (
                    <button className="deletarall" onClick={deletarTodos}>Deletar Todas</button>
                )}
            </div>
            <footer>
                <h1>
                    Matheus Gomes Reinaldo <br /> matrícula: 01763987 <br /> 
                </h1>
            </footer>
        </div>
    );
}

export default TodoList;
